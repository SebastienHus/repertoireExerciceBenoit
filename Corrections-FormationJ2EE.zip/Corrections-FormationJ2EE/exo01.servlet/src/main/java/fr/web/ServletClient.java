package fr.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.banque.Client;
import fr.bd.AccesBD;

/**
 * Servlet qui va afficher tous les clients. <br/>
 */
@WebServlet(description = "Affiche tous les clients", urlPatterns = { "/ServletClient" })
public class ServletClient extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final String DB_DRIVER = "com.mysql.jdbc.Driver";
	private static final String DB_URL = "jdbc:mysql://localhost/banque?useSSL=false";
	private static final String DB_LOGIN = "root";
	private static final String DB_PWD = "";

	/**
	 * Constructeur.
	 */
	public ServletClient() {
		super();
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		AccesBD bd = null;
		try {
			// Recuperation des clients
			bd = new AccesBD(ServletClient.DB_DRIVER);
			bd.seConnecter(ServletClient.DB_URL, ServletClient.DB_LOGIN, ServletClient.DB_PWD);
			List<Client> lClients = bd.selectUtilisateur();
			StringBuilder buffer = new StringBuilder();
			buffer.append(
					"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
			buffer.append("<html>");
			buffer.append("<head>");
			buffer.append("<title>Tous les clients</title>");
			buffer.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
			buffer.append("</head>");
			buffer.append("<body>");
			buffer.append("<center>");
			if (!lClients.isEmpty()) {
				buffer.append("<h1>Les Clients</h1>");
				buffer.append("<table border=\"1\" width=\"100%\">");
				buffer.append("<tr>");
				buffer.append("<td align=\"center\"><h2>Nom</h2></td>");
				buffer.append("<td align=\"center\"><h2>Prenom</h2></td>");
				buffer.append("<td align=\"center\"><h2>Age</h2></td>");
				buffer.append("<td></td>");
				buffer.append("</tr>");
				Iterator<Client> iterClient = lClients.iterator();
				while (iterClient.hasNext()) {
					Client client = iterClient.next();
					// Fabrication de la page
					buffer.append("<tr>");
					buffer.append("<td align=\"center\">").append(client.getNom()).append("</td>");
					buffer.append("<td align=\"center\">").append(client.getPrenom()).append("</td>");
					if (client.getAge() > 0) {
						buffer.append("<td align=\"center\">").append(client.getAge()).append("</td>");
					} else {
						buffer.append("<td align=\"center\">&nbsp;</td>");

					}
					buffer.append("<td align=\"center\">");
					buffer.append("<form action=\"ServletCompte\" method=\"post\">");
					buffer.append("<input type=\"hidden\" name=\"id\" value=\"").append(client.getNumero())
							.append("\">");
					buffer.append("<input type=\"submit\" value=\"Voir ses comptes\">");
					buffer.append("</form>");
					buffer.append("</td>");
					buffer.append("</tr>");
				}
				buffer.append("</table>");
			} else {
				buffer.append("Aucun client.");
			}
			buffer.append("</center>");
			buffer.append("</body>");
			buffer.append("</html>");

			// On ecrit le flux de retour
			response.getWriter().print(buffer.toString());

		} catch (SQLException e) {
			// NE JAMAIS FAIRE EN WEB
			// e.printStackTrace();
			response.getWriter().print("Erreur dans la servlet (" + e.getMessage() + ")");
		} finally {
			if (bd != null) {
				bd.seDeconnecter();
			}
		}

	}
}
