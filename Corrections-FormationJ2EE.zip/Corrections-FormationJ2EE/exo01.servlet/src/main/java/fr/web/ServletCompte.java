package fr.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.banque.Compte;
import fr.banque.ICompteASeuil;
import fr.banque.ICompteRemunere;
import fr.bd.AccesBD;

/**
 * Servlet qui va afficher tous les comptes d'un client. <br/>
 */
@WebServlet(description = "Affiche tous les comptes d'un client", urlPatterns = { "/ServletCompte" })
public class ServletCompte extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final String DB_DRIVER = "com.mysql.jdbc.Driver";
	private static final String DB_URL = "jdbc:mysql://localhost/banque?useSSL=false";
	private static final String DB_LOGIN = "root";
	private static final String DB_PWD = "";

	/**
	 * Constructeur.
	 */
	public ServletCompte() {
		super();
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		AccesBD bd = null;
		try {
			// Recuperation des clients
			bd = new AccesBD(ServletCompte.DB_DRIVER);
			bd.seConnecter(ServletCompte.DB_URL, ServletCompte.DB_LOGIN, ServletCompte.DB_PWD);
			StringBuilder buffer = new StringBuilder();
			buffer.append(
					"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
			buffer.append("<html>");
			buffer.append("<head>");
			buffer.append("<title>Tous les comptes du client</title>");
			buffer.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
			buffer.append("</head>");
			buffer.append("<body>");
			buffer.append("<center>");

			// Recuperation de l'id de l'utilisateur qui se trouve en tant que
			// parametre de request
			String idUtilisateur = request.getParameter("id");
			if (idUtilisateur == null || idUtilisateur.trim().isEmpty()) {
				// Erreur ....
				buffer.append("Id utilisateur absent.");
			} else {
				Integer idUt = null;
				try {
					idUt = Integer.valueOf(idUtilisateur);
				} catch (Exception e) {
					buffer.append("Id utilisateur absent incorrecte");
				}
				if (idUt != null) {
					List<Compte> lCompte = bd.selectCompte(idUt);
					if (!lCompte.isEmpty()) {
						buffer.append("<h1>Les Comptes du client</h1>");
						buffer.append("<table border=\"1\" width=\"100%\">");
						buffer.append("<tr>");
						buffer.append("<td align=\"center\"><h2>Solde</h2></td>");
						buffer.append("<td align=\"center\"><h2>Taux</h2></td>");
						buffer.append("<td align=\"center\"><h2>Seuil</h2></td>");
						buffer.append("</tr>");

						Iterator<Compte> iterCpt = lCompte.iterator();
						while (iterCpt.hasNext()) {
							Compte compte = iterCpt.next();
							// Fabrication de la page
							buffer.append("<tr>");
							buffer.append("<td align=\"center\">").append(compte.getSolde()).append("</td>");

							// On remarque ici que si on fait passer la methode
							// getTaux dans l'interface ICompteRemunere, alors
							// le code deviendrait beaucoup plus simple
							if (compte instanceof ICompteRemunere) {
								buffer.append("<td align=\"center\">").append(((ICompteRemunere) compte).getTaux())
										.append("</td>");
							} else {
								buffer.append("<td align=\"center\">--</td>");
							}

							// On remarque ici que si on fait passer la methode
							// getSeuil dans l'interface ICompteASeuil, alors
							// le code deviendrait beaucoup plus simple
							if (compte instanceof ICompteASeuil) {
								buffer.append("<td align=\"center\">").append(((ICompteASeuil) compte).getSeuil())
										.append("</td>");
							} else {
								buffer.append("<td align=\"center\">--</td>");
							}

							buffer.append("</tr>");
						}
						buffer.append("</table>");
					} else {
						buffer.append("Aucun compte.");
					}
				}
			}
			buffer.append("</center>");
			buffer.append("</body>");
			buffer.append("</html>");

			// On ecrit le flux de retour
			response.getWriter().print(buffer.toString());

		} catch (SQLException e) {
			// NE JAMAIS FAIRE EN WEB
			// e.printStackTrace();
			response.getWriter().print("Erreur dans la servlet (" + e.getMessage() + ")");
		} finally {
			if (bd != null) {
				bd.seDeconnecter();
			}
		}

	}
}
