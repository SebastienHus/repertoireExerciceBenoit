package com.banque.web;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Servlet qui va gerer les utilisateurs connectes. <br/>
 */
@WebServlet(urlPatterns = { "/ServletUtilisateursConnectes" })
public class ServletUtilisateursConnectes extends AbstractServlet {
	private static final Logger LOG = LogManager.getLogger();
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur.
	 */
	public ServletUtilisateursConnectes() {
		super();
	}

	@Override
	protected String vraiService(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Integer idUtilisateur = this.getUserId(request);
		ServletUtilisateursConnectes.LOG.info("Affichage de la liste des utilisateurs pour l'utilisateur {} ",
				idUtilisateur);

		// Rien de particulier a faire puisque la liste est dans le scope
		// application
		return "listeUtilisateurs.jsp";
	}

	@Override
	protected String getErrorPage() {
		return "login.jsp";
	}

}
