package com.banque.web;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.banque.entity.IOperationEntity;
import com.banque.service.IOperationService;
import com.banque.service.impl.OperationService;

/**
 * Servlet qui va afficher les historiques d'operation d'un client. <br/>
 */
@WebServlet(urlPatterns = { "/ServletHistorique" })
public class ServletHistorique extends AbstractServlet {
	private static final Logger LOG = LogManager.getLogger();
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur.
	 */
	public ServletHistorique() {
		super();
	}

	@Override
	protected String vraiService(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String idCpt = request.getParameter("inNumeroCompte");
		Integer compteId = null;
		try {
			compteId = Integer.valueOf(idCpt);
		} catch (Exception e1) {
			ServletHistorique.LOG.trace("L'id du compte est invalide", e1);
			this.enregistrerMessageErreur(request, "L'id du compte est invalide (" + e1.getMessage() + ")", e1);
			return "menu.jsp";
		}
		// On regarde si on a des criteres pour les operations
		String inDateDebut = request.getParameter("inDateDebut");
		String inDateFin = request.getParameter("inDateFin");
		String inCredit = request.getParameter("inCredit");
		String inDebit = request.getParameter("inDebit");
		// Par defaut un checkbox vaut on ou rien
		boolean credit = "true".equalsIgnoreCase(inCredit) || "yes".equalsIgnoreCase(inCredit)
				|| "on".equalsIgnoreCase(inCredit);
		boolean debit = "true".equalsIgnoreCase(inDebit) || "yes".equalsIgnoreCase(inDebit)
				|| "on".equalsIgnoreCase(inDebit);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		// Pas de calcul heuristique
		sdf.setLenient(false);

		Date dateDeb = null;
		if (inDateDebut != null && !inDateDebut.trim().isEmpty()) {
			try {
				dateDeb = new Date(sdf.parse(inDateDebut.trim()).getTime());
			} catch (Exception e) {
				ServletHistorique.LOG.trace("Votre date de début n'est pas correcte", e);
				this.enregistrerMessageErreur(request,
						"Votre date de début n'est pas correcte (" + e.getMessage() + ")", e);
				return this.getErrorPage();
			}
		}

		Date dateFin = null;
		if (inDateFin != null && !inDateFin.trim().isEmpty()) {
			try {
				dateFin = new Date(sdf.parse(inDateFin.trim()).getTime());
			} catch (ParseException e) {
				ServletHistorique.LOG.trace("Votre date de fin n'est pas correcte", e);
				this.enregistrerMessageErreur(request, "Votre date de fin n'est pas correcte (" + e.getMessage() + ")",
						e);
				return this.getErrorPage();
			}
		}

		if (dateFin != null && dateDeb != null && dateFin.before(dateDeb)) {
			Date tmp = dateFin;
			dateFin = dateDeb;
			dateDeb = tmp;
		}
		Integer idUtilisateur = this.getUserId(request);
		ServletHistorique.LOG.info("Affichage des operations de l'utilisateur {} pour le compte {}", idUtilisateur,
				compteId);
		IOperationService service = new OperationService();
		List<IOperationEntity> listeOpt = service.selectCritere(idUtilisateur.intValue(), compteId.intValue(), dateDeb,
				dateFin, credit, debit);
		// On les places dans la request
		request.setAttribute("listeOpt", listeOpt);
		// On replace l'id et les parametres afin de pouvoir les
		// reafficher
		request.setAttribute("pIdCpt", idCpt);
		request.setAttribute("pDateDebut", inDateDebut);
		request.setAttribute("pDateFin", inDateFin);
		request.setAttribute("pCredit", credit ? Boolean.TRUE : Boolean.FALSE);
		request.setAttribute("pDebit", debit ? Boolean.TRUE : Boolean.FALSE);
		// On part vers la page qui liste les operations
		return "comptes/historique.jsp";
	}

	@Override
	protected String getErrorPage() {
		return "comptes/historique.jsp";
	}
}
