package com.banque.web;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Servlet qui va afficher le menu. <br/>
 */
@WebServlet(urlPatterns = { "/ServletMenu" })
public class ServletMenu extends AbstractServlet {
	private static final Logger LOG = LogManager.getLogger();
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur.
	 */
	public ServletMenu() {
		super();
	}

	@Override
	protected String vraiService(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Integer idUtilisateur = this.getUserId(request);
		ServletMenu.LOG.info("Affichage du menu pour l'utilisateur {} ", idUtilisateur);
		return "menu.jsp";
	}

	@Override
	protected String getErrorPage() {
		return "login.jsp";
	}
}
