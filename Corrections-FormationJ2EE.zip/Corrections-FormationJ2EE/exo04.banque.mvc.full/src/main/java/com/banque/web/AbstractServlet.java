package com.banque.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Servlet parente qui regroupe les fonctionnalites : <br/>
 * <ul>
 * <li>chargement des acces a la base</li>
 * <li>gestion de l'authentifictaion</li>
 * </ul>
 */
public abstract class AbstractServlet extends HttpServlet {
	private static final Logger LOG = LogManager.getLogger();
	/**
	 * Clef utilisee lors de l'authentification. Contiendra l'id de
	 * l'utilisateur.
	 */
	public static final String CLEF_AUTHENTIFICATION = "idUtilisateur";
	/** Clef utilisee pour l'utilisateur. Contiendra l'utilisateur. */
	public static final String CLEF_UTILISATEUR = "utilisateur";
	/** Clef utilisee pour contenir l'ip de l'utilisateur. */
	public static final String CLEF_UTILISATEUR_IP = "utilisateurIp";
	/** Clef utilisee pour les messages d'erreurs. */
	public static final String CLEF_ERREUR = "erreur";
	/** L'URI de la page login. */
	public static final String PAGE_LOGIN = "login.jsp";

	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur.
	 */
	AbstractServlet() {
		super();
	}

	/**
	 * Recupere l'id de l'utilisateur connecte.
	 *
	 * @param request
	 *            une requete
	 * @return null ou l'id de l'utilisateur
	 */
	protected final Integer getUserId(HttpServletRequest request) {
		return (Integer) request.getSession(true).getAttribute(AbstractServlet.CLEF_AUTHENTIFICATION);
	}

	/**
	 * Enregistre un message d'erreur et fait un log.
	 *
	 * @param request
	 *            la request
	 * @param unMessage
	 *            le message
	 * @param uneException
	 *            une exception (peut etre null)
	 */
	protected void enregistrerMessageErreur(HttpServletRequest request, String unMessage, Throwable uneException) {
		request.setAttribute(AbstractServlet.CLEF_ERREUR, unMessage);
		AbstractServlet.LOG.error("Erreur : {}", unMessage, uneException);
	}

	/**
	 * Code metier reel realise par la servlet. <br/>
	 *
	 * @param request
	 *            la request
	 * @param response
	 *            la response
	 * @return url de destination
	 * @throws Exception
	 *             si un probleme survient
	 *
	 */
	protected abstract String vraiService(HttpServletRequest request, HttpServletResponse response) throws Exception;

	/**
	 * Donne l'url de la page d'erreur.
	 *
	 * @return l'url de la page d'erreur.
	 */
	protected abstract String getErrorPage();

	@Override
	protected final void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String destination = this.getErrorPage();
		try {
			destination = this.vraiService(request, response);
		} catch (Exception e) {
			this.enregistrerMessageErreur(request, "Probleme (" + e.getMessage() + ")", e);
		}
		request.getRequestDispatcher(destination).forward(request, response);
	}
}
