package com.banque.web;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.banque.entity.IUtilisateurEntity;
import com.banque.service.IAuthentificationService;
import com.banque.service.impl.AuthentificationService;

/**
 * Servlet qui va gerer le login du client. <br/>
 */
@WebServlet(urlPatterns = { "/ServletLogin" })
public class ServletLogin extends AbstractServlet {
	private static final Logger LOG = LogManager.getLogger();
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur.
	 */
	public ServletLogin() {
		super();
	}

	@Override
	protected String vraiService(HttpServletRequest request, HttpServletResponse response) throws Exception {

		// Recupere les parametres qui viennent de la JSP
		String login = request.getParameter("inLogin");
		String pwd = request.getParameter("inPass");
		ServletLogin.LOG.info("Login de l'utilisateur {} ", login);
		if (login == null || pwd == null || login.trim().isEmpty() || pwd.trim().isEmpty()) {
			this.enregistrerMessageErreur(request, "Vous devez indiquer un login et mot de passe non vide", null);
			return this.getErrorPage();
		} else {
			IAuthentificationService auth = new AuthentificationService();
			// On verifie que le tout est ok
			try {
				IUtilisateurEntity user = auth.authentifier(login, pwd);
				// A placer en premier dans la session
				request.getSession(true).setAttribute(AbstractServlet.CLEF_UTILISATEUR_IP, request.getRemoteAddr());
				request.getSession(true).setAttribute(AbstractServlet.CLEF_UTILISATEUR, user);
				request.getSession(true).setAttribute(AbstractServlet.CLEF_AUTHENTIFICATION, user.getId());
			} catch (Exception e) {
				ServletLogin.LOG.trace("Votre login/pwd n'est pas valide", e);
				this.enregistrerMessageErreur(request, "Votre login/pwd n'est pas valide", null);
				return this.getErrorPage();
			}
		}
		return "menu.jsp";
	}

	@Override
	protected String getErrorPage() {
		return "login.jsp";
	}

}
