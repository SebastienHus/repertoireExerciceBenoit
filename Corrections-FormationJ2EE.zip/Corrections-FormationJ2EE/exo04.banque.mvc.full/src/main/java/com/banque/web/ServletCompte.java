package com.banque.web;

import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.banque.entity.ICompteEntity;
import com.banque.service.ICompteService;
import com.banque.service.impl.CompteService;

/**
 * Servlet qui va afficher tous les comptes d'un client. <br/>
 */
@WebServlet(urlPatterns = { "/ServletCompte" })
public class ServletCompte extends AbstractServlet {
	private static final Logger LOG = LogManager.getLogger();
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur.
	 */
	public ServletCompte() {
		super();
	}

	@Override
	protected String vraiService(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Integer idUtilisateur = this.getUserId(request);
		ServletCompte.LOG.info("Affichage des comptes de l'utilisateur {}", idUtilisateur);
		ICompteService service = new CompteService();
		List<ICompteEntity> listeCpt = service.selectAll(idUtilisateur.intValue());
		request.setAttribute("listeCpt", listeCpt);
		return "comptes/liste.jsp";
	}

	@Override
	protected String getErrorPage() {
		return "comptes/liste.jsp";
	}
}
