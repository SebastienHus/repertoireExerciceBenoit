package com.banque.web;

import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.banque.entity.ICompteEntity;
import com.banque.service.ICompteService;
import com.banque.service.IOperationService;
import com.banque.service.impl.CompteService;
import com.banque.service.impl.OperationService;

/**
 * Servlet qui va afficher les historiques d'operation d'un client. <br/>
 */
@WebServlet(urlPatterns = { "/ServletVirement" })
public class ServletVirement extends AbstractServlet {
	private static final Logger LOG = LogManager.getLogger();
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur.
	 */
	public ServletVirement() {
		super();
	}

	@Override
	protected String vraiService(HttpServletRequest request, HttpServletResponse response) throws Exception {

		// On recupere l'id qui est dans la session
		Integer idUtilisateur = this.getUserId(request);

		// On cherche les parametres
		String inCmptEme = request.getParameter("inCmptEme");
		String inCmptDes = request.getParameter("inCmptDes");
		String inMontant = request.getParameter("inMontant");
		// Si les parametres sont la
		if (inCmptEme != null && inCmptDes != null && inMontant != null) {
			Integer cmptEme = null;
			try {
				cmptEme = Integer.valueOf(inCmptEme);
			} catch (Exception e1) {
				ServletVirement.LOG.trace("Compte source invalide", e1);
				this.enregistrerMessageErreur(request, "Compte source invalide (" + e1.getMessage() + ")", null);
			}

			Integer cmptDes = null;
			try {
				cmptDes = Integer.valueOf(inCmptDes);
			} catch (Exception e1) {
				ServletVirement.LOG.trace("Compte destination invalide", e1);
				this.enregistrerMessageErreur(request, "Compte destination invalide (" + e1.getMessage() + ")", null);
			}
			ServletVirement.LOG.info("Gestion du virement pour l'utilisateur {} entre le compte {} et {}",
					idUtilisateur, cmptEme, cmptDes);
			Double montant = null;
			try {
				montant = Double.valueOf(inMontant);
			} catch (Exception e1) {
				ServletVirement.LOG.trace("Montant invalide", e1);
				this.enregistrerMessageErreur(request, "Montant invalide (" + e1.getMessage() + ")", null);
			}

			request.setAttribute("pCmptEme", cmptEme);
			request.setAttribute("pCmptDes", cmptDes);
			request.setAttribute("pMontant", inMontant);

			if (montant != null && montant.doubleValue() <= 0) {
				this.enregistrerMessageErreur(request, "Votre montant doit etre strictement positif.", null);
				return this.getErrorPage();
			}
			if (cmptEme != null && cmptDes != null && montant != null) {
				IOperationService serviceOp = new OperationService();
				serviceOp.faireVirement(idUtilisateur.intValue(), cmptEme.intValue(), cmptDes.intValue(),
						montant.doubleValue());
				request.setAttribute("message", "Votre virement s'est bien passé.");
				return "menu.jsp";
			}
		}
		ICompteService serviceSpt = new CompteService();
		List<ICompteEntity> listeCpt = serviceSpt.selectAll(idUtilisateur.intValue());
		request.setAttribute("listeCpt", listeCpt);
		return this.getErrorPage();
	}

	@Override
	protected String getErrorPage() {
		return "comptes/virement.jsp";
	}
}
