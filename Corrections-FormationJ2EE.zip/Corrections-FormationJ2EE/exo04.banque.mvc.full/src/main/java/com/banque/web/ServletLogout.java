package com.banque.web;

import java.util.Enumeration;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Servlet qui va gerer la deconnection. <br/>
 */
@WebServlet(urlPatterns = { "/ServletLogout" })
public class ServletLogout extends AbstractServlet {
	private static final Logger LOG = LogManager.getLogger();
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur.
	 */
	public ServletLogout() {
		super();
	}

	@Override
	protected String vraiService(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// Ici, le listener UtilisateursConnectesListener se chargera de retirer
		// l'utilisateur de la liste des personnes connectees
		ServletLogout.LOG.info("Deconnection de l'utilisateur {}", this.getUserId(request));
		HttpSession session = request.getSession(true);
		Enumeration<String> toutesLesClefs = session.getAttributeNames();
		while (toutesLesClefs.hasMoreElements()) {
			String uneClef = toutesLesClefs.nextElement();
			session.removeAttribute(uneClef);
		}
		session.invalidate();
		return "login.jsp";
	}

	@Override
	protected String getErrorPage() {
		return "login.jsp";
	}
}
