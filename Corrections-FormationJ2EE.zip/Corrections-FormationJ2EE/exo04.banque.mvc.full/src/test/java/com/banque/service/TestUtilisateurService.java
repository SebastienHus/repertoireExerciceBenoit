package com.banque.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.banque.entity.IUtilisateurEntity;
import com.banque.service.ex.MauvaisMotdepasseException;
import com.banque.service.ex.UtilisateurInconnuException;
import com.banque.service.impl.AuthentificationService;

/**
 * Test sur la classe IAuthentificationService.
 */
public class TestUtilisateurService {
	private static final Logger LOG = LogManager.getLogger();
	private IAuthentificationService authentificationService;

	/**
	 * Execute avant chaque methode de test. <br/>
	 * Initialise le service d'authentification.
	 *
	 * @throws Exception
	 *             si un probleme survient
	 */
	@Before
	public void before() throws Exception {
		this.authentificationService = new AuthentificationService();
	}

	/**
	 * Execute apres chaque methode de test. <br/>
	 * Detruit le service d'authentification.
	 *
	 * @throws Exception
	 *             si un probleme survient
	 */
	@After
	public void after() throws Exception {
		this.authentificationService = null;
	}

	/**
	 * Test l'authentification.
	 */
	@Test
	public void testAuthentifierOk() {
		final String login = "df";
		final String pwd = "df";
		IUtilisateurEntity user = null;
		try {
			user = this.authentificationService.authentifier(login, pwd);
		} catch (Exception e) {
			TestUtilisateurService.LOG.error("Erreur", e);
			Assert.fail(e.getMessage());
		}
		Assert.assertNotNull("L'utilisateur ne doit pas etre null", user);
		Assert.assertEquals("Le login de l'utilisateur est " + login, user.getLogin(), login);
	}

	/**
	 * Test l'authentification.
	 *
	 * @throws Exception
	 *             attend un UtilisateurInconnuException
	 */
	@Test(expected = UtilisateurInconnuException.class)
	public void testAuthentifierKo1() throws Exception {
		final String login = "dfd";
		final String pwd = "df";
		this.authentificationService.authentifier(login, pwd);
	}

	/**
	 * Test l'authentification.
	 *
	 * @throws Exception
	 *             attend un MauvaisMotdepasseException
	 */
	@Test(expected = MauvaisMotdepasseException.class)
	public void testAuthentifierKo2() throws Exception {
		final String login = "df";
		final String pwd = "dfd";
		this.authentificationService.authentifier(login, pwd);
	}

}
