package com.banque.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.banque.entity.ICompteEntity;
import com.banque.service.ex.AucunDroitException;
import com.banque.service.ex.EntityIntrouvableException;
import com.banque.service.impl.CompteService;

/**
 * Test sur la classe ICompteService.
 */
public class TestCompteService {
	private static final Logger LOG = LogManager.getLogger();
	private ICompteService compteService;

	/**
	 * Execute avant chaque methode de test. <br/>
	 * Initialise le service de compte.
	 *
	 * @throws Exception
	 *             si un probleme survient
	 */
	@Before
	public void before() throws Exception {
		this.compteService = new CompteService();
	}

	/**
	 * Execute apres chaque methode de test. <br/>
	 * Detruit le service de compte.
	 *
	 * @throws Exception
	 *             si un probleme survient
	 */
	@After
	public void after() throws Exception {
		this.compteService = null;
	}

	/**
	 * Test de selection.
	 */
	@Test
	public void selectOk() {
		final int unUtilisateurId = 1;
		final int unCompteId = 12;
		ICompteEntity cpt = null;
		try {
			cpt = this.compteService.select(unUtilisateurId, unCompteId);
		} catch (Exception e) {
			TestCompteService.LOG.error("Erreur", e);
			Assert.fail(e.getMessage());
		}
		Assert.assertNotNull("Le compte ne doit pas etre null", cpt);
		Assert.assertEquals("L'id du compte doit etre " + unCompteId, cpt.getId().intValue(), unCompteId);
	}

	/**
	 * Test de gestion des droits sur un compte
	 *
	 * @throws Exception
	 *             on attend un AucunDroitException
	 */
	@Test(expected = AucunDroitException.class)
	public void selectKo1() throws Exception {
		// il n'y a pas d'utilisateur 100
		final int unUtilisateurId = 100;
		// il y a un compte 12
		final int unCompteId = 12;
		this.compteService.select(unUtilisateurId, unCompteId);
	}

	/**
	 * Test de gestion des droits sur un compte
	 *
	 * @throws Exception
	 *             on attend un EntityIntrouvableException
	 */
	@Test(expected = EntityIntrouvableException.class)
	public void selectKo2() throws Exception {
		// il y a un utilisateur 1
		final int unUtilisateurId = 1;
		// il n'y a pas de compte 1200000
		final int unCompteId = 1200000;
		this.compteService.select(unUtilisateurId, unCompteId);
	}

	/**
	 * Test de selection.
	 */
	@Test
	public void selectAllOk() {
		// il y a un utilisateur 1
		final int unUtilisateurId = 1;
		List<ICompteEntity> liste = null;
		try {
			liste = this.compteService.selectAll(unUtilisateurId);
		} catch (Exception e) {
			TestCompteService.LOG.error("Erreur", e);
			Assert.fail(e.getMessage());
		}
		Assert.assertNotNull("La liste ne doit pas etre null", liste);
		Assert.assertFalse("La liste ne doit pas etre vide", liste.isEmpty());
		for (ICompteEntity compteEntity : liste) {
			Assert.assertNotNull("Le compte ne doit pas etre null", compteEntity);
			Assert.assertEquals("Le compte doit avoir un user id = " + unUtilisateurId,
					compteEntity.getUtilisateurId().intValue(), unUtilisateurId);
		}
	}

}
