package fr.banque;

/**
 * Interface representant un compte remunere. <br/>
 *
 * Ici en Java 8 la competence verser et calculer interets sont dans
 * l'interface.
 *
 * @since 1.8
 */
public interface ICompteRemunere extends ICompte {

	/**
	 * Calcul les interets par rapport au solde actuel.
	 *
	 * @return les interets par rapport au solde actuel.
	 *
	 * @since 1.8
	 */
	public default double calculerInterets() {
		return this.getSolde() * this.getTaux();
	}

	/**
	 * Verse les interets par rapport au solde actuel.
	 *
	 * @since 1.8
	 */
	public default void verserInterets() {
		this.ajouter(this.calculerInterets());
	}

	/**
	 * Recupere le taux.
	 *
	 * @return le taux
	 */
	public abstract double getTaux();

	/**
	 * Modifie la valeur du taux.
	 *
	 * @param taux
	 *            le nouveau taux, entre [0, 1[.
	 * @throws IllegalArgumentException
	 *             si le taux est invalid
	 */
	public abstract void setTaux(double taux);

}