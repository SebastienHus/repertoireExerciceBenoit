package fr;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import fr.xml.Adresse;
import fr.xml.Personne;

/**
 * Classe qui fabrique des personnes et des adresses et qui les sauvegardes dans
 * un fichier XML. <br/>
 * Exemple d'utilisation de JAXB. <br/>
 */
public class Run {

	/**
	 * Methode de lancement.
	 *
	 * @param args
	 *            ne sert pas ici
	 */
	public static void main(String[] args) {
		// Pensez a verifier les chemins des deux fichiers ci dessous
		final String root = "T:/Workspace/Exo13-JAX-B/src/main/resources/";
		final String fichierSortie = root + "resultat.xml";
		final String fichierEntree = root + "lire.xml";
		System.out.println("-- Debut --");
		// Instentiation des adresses
		Adresse adr01 = new Adresse();
		adr01.setCodePostal(78000);
		adr01.setPays("France");
		adr01.setRue("Pave des gardes");
		adr01.setVille("Versailles");
		Adresse adr02 = new Adresse();
		adr02.setCodePostal(75000);
		adr02.setPays("France");
		adr02.setRue("rue des pres");
		adr02.setVille("Paris");
		// Instentiation de la liste d'adresse
		List<Adresse> listeAdresses = new ArrayList<Adresse>();
		listeAdresses.add(adr01);
		listeAdresses.add(adr02);
		// Instentiation d'une personne
		Personne personne = new Personne();
		personne.setAdresses(listeAdresses);
		personne.setNom("Smith");
		personne.setPrenom("Jhon");
		// Pour la date de naissance on utilise la classe Calendar
		Calendar cl = new GregorianCalendar();
		cl.set(Calendar.YEAR, 1985);
		cl.set(Calendar.MONTH, Calendar.DECEMBER);
		cl.set(Calendar.DAY_OF_MONTH, 18);
		personne.setDateNaissance(cl.getTime());
		// Creation du fichier de sortie
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(Personne.class, Adresse.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			jaxbMarshaller.marshal(personne, new File(fichierSortie));
		} catch (Exception e) {
			e.printStackTrace();
		}
		// Lecture du fichier
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(Personne.class, Adresse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			Personne personneLue = (Personne) jaxbUnmarshaller.unmarshal(new File(fichierEntree));
			System.out.println(personneLue);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("-- Fin --");
	}

}
