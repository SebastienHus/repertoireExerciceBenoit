package fr.xml;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.adapters.XmlAdapter;

/**
 * Date adapter pour JAXB.<br/>
 * Permet de gerer proprement les dates. <br/>
 */
public class DateAdapter extends XmlAdapter<String, Date> {
	private static final String DATE_PATTERN = "dd/MM/yyyy";
	private SimpleDateFormat dateFormat;

	/**
	 * Constructor of the object.
	 */
	public DateAdapter() {
		super();
		this.dateFormat = new SimpleDateFormat(DateAdapter.DATE_PATTERN);
		this.dateFormat.setLenient(false);
	}

	@Override
	public Date unmarshal(String aV) throws Exception {
		if (aV == null || aV.trim().isEmpty()) {
			return null;
		}
		java.util.Date result;
		// SimpleDateFormat n'etant pas thread safe il est preferable de
		// l'utiliser dans un bloque synchronized
		synchronized (this.dateFormat) {
			result = this.dateFormat.parse(aV);
		}
		return new java.sql.Date(result.getTime());
	}

	@Override
	public String marshal(Date aV) throws Exception {
		if (aV == null) {
			return null;
		}
		String result;
		// SimpleDateFormat n'etant pas thread safe il est preferable de
		// l'utiliser dans un bloque synchronise
		synchronized (this.dateFormat) {
			result = this.dateFormat.format(aV);
		}
		return result;
	}

}
