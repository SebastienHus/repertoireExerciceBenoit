package fr.exo01;

/**
 * Premiere classe d'exemple. <br>
 *
 * Pour lancer (rendre executable) un programme java il faut imperativement
 * qu'il possede une methode <b>public static void main(String args[])</b>.
 * <br/>
 * <br/>
 * Il est <u>imperatif</u> de respecter exactement <b>mot pour mot</b> le
 * prototypage de cette methode. <br/>
 * <br/>
 *
 * Pour compiler en ligne de commande :<br/>
 * javac SecondExo.java<br/>
 * Pour executer en ligne de commande :<br/>
 * java SecondExo<br/>
 * <br/>
 * Sous Eclipse, faites un clique droit sur votre classe qui possede une methode
 * main, puis Run As/Java Application.<br/>
 *
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
public class SecondExo {

	/**
	 * Lancement de l'application. <br>
	 *
	 * @param args
	 *            les arguments de lancement (Parametres de l'application), java
	 *            Bonjour arg0 arg1 arg2 ...
	 */
	public static void main(String[] args) {
		// L'affichage sur la sortie standard se fait par System.out.println
		System.out.println("Bonjour tout le monde");
		// affichage des parametres
		if (args.length > 0) {
			System.out.println("Les arguments donnes sont:");
			for (int i = 0; i < args.length; i++) {
				// On peut utiliser la concatenation de chaine en Java
				System.out.println(" [" + i + "] " + args[i]);
				// Par exemple
				// System.out.println("
				// [".concat(String.valueOf(i)).concat("]").concat(args[i]));
				// System.out.format("[%d] %s", i, args[i]);
			}
		}
	}
}