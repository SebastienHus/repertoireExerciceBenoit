package fr.dessin;

/**
 * La classe Point2D. <br/>
 */
public class Point2D {
	/** Attribut X. Par defaut en Java, sera initialise a zero. */
	private int x;
	/** Attribut Y. Par defaut en Java, sera initialise a zero. */
	private int y;

	/**
	 * Constructeur.
	 */
	public Point2D() {
		super();// = appel du constructeur parent sans parametre
		// Ou :
		// this(0,0); : dans ce cas, appel au constructeur qui se trouve dans
		// cette classe et qui prend deux entiers qui auront comme valeur 0
	}

	/**
	 * Constructeur.
	 *
	 * @param vX
	 *            valeur pour x
	 * @param vY
	 *            valeur pour y
	 */
	public Point2D(int vX, int vY) {
		super(); // = appel du constructeur parent sans parametre
		// super() ou this() doit imperativement etre la premiere
		// ligne de code de votre constructeur
		//
		this.setX(vX);
		this.setY(vY);
		// ou
		// this.x = vX;
		// this.y = vY;
		// Meme si le code est correcte ne pas faire :
		// this.translater(vX, vY);
	}

	/**
	 * Affiche l'objet sur la sortie standard. <br/>
	 */
	public void afficher() {
		System.out.println("Point2D [" + this.getX() + ", " + this.getY() + "]");
	}

	/**
	 * Recupere la valeur de x.
	 *
	 * @return la valeur de x.
	 */
	public int getX() {
		return this.x;
	}

	/**
	 * Recupere la valeur de y.
	 *
	 * @return la valeur de y.
	 */
	public int getY() {
		return this.y;
	}

	/**
	 * Modifie la valeur de x. <br/>
	 *
	 * @param valX
	 *            la nouvelle valeur de x
	 */
	public void setX(int valX) {
		this.x = valX;
	}

	/**
	 * Modifie la valeur de y. <br/>
	 *
	 * @param valY
	 *            la nouvelle valeur de y
	 */
	public void setY(int valY) {
		this.y = valY;
	}

	/**
	 * Translate le point. <br/>
	 *
	 * @param dX
	 *            valeur de translation en x
	 * @param dY
	 *            valeur de translation en y
	 */
	public void translater(int dX, int dY) {
		this.setX(this.getX() + dX);
		this.setY(this.getY() + dY);
	}
}