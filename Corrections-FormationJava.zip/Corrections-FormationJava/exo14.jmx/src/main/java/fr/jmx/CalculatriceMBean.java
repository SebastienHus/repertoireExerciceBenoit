package fr.jmx;

/**
 * Interface representant une calculatrice. <br/>
 *
 * Respectez bien le nom de l'interface [NomDuBean]MBean.
 */
public interface CalculatriceMBean {

	/**
	 * Additionne deux valeurs.
	 *
	 * @param c1
	 *            valeur 1
	 * @param c2
	 *            valeur 2
	 * @return c1+c2
	 */
	public abstract double add(double c1, double c2);

	/**
	 * Soustrait deux valeurs.
	 *
	 * @param c1
	 *            valeur 1
	 * @param c2
	 *            valeur 2
	 * @return c1-c2
	 */
	public abstract double sub(double c1, double c2);

	/**
	 * Multiplie deux valeurs.
	 *
	 * @param c1
	 *            valeur 1
	 * @param c2
	 *            valeur 2
	 * @return c1*c2
	 */
	public abstract double mult(double c1, double c2);

	/**
	 * Divise deux valeurs.
	 *
	 * @param c1
	 *            valeur 1
	 * @param c2
	 *            valeur 2
	 * @return c1/c2, si c2 == 0 alors Double.NaN
	 */
	public abstract double div(double c1, double c2);

	/**
	 * Recupere le dernier resultat
	 *
	 * @return le dernier resultat
	 */
	public abstract double getDernierResultat();

}