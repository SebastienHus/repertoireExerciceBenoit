package fr.jmx;

/**
 * Classe representant une calculatrice. <br/>
 *
 * @see "https://docs.oracle.com/javase/8/docs/technotes/guides/jmx/examples.html"
 */
public class Calculatrice implements CalculatriceMBean {
	private double dernierResultat;

	/**
	 * Constructeur.
	 */
	public Calculatrice() {
		super();
	}

	@Override
	public double add(double c1, double c2) {
		double resultat = c1 + c2;
		this.dernierResultat = resultat;
		return resultat;
	}

	@Override
	public double sub(double c1, double c2) {
		double resultat = c1 - c2;
		this.dernierResultat = resultat;
		return resultat;
	}

	@Override
	public double mult(double c1, double c2) {
		double resultat = c1 * c2;
		this.dernierResultat = resultat;
		return resultat;
	}

	@Override
	public double div(double c1, double c2) {
		if (c2 != 0) {
			double resultat = c1 / c2;
			this.dernierResultat = resultat;
			return resultat;
		}
		return Double.NaN;
	}

	@Override
	public double getDernierResultat() {
		return this.dernierResultat;
	}
}
