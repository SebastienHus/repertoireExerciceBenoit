package fr.banque;

/**
 * Interface representant un compte a seuil.
 */
public interface ICompteASeuil {

	/**
	 * Retire l'argent si c'est possible.
	 *
	 * @param unMontant
	 *            un montant a retirer
	 */
	public abstract void retirer(double unMontant);

	/**
	 * Recupere le seuil.
	 *
	 * @return le seuil
	 */
	public abstract double getSeuil();

	/**
	 * Modifie la valeur du seuil.
	 *
	 * @param unSeuil
	 *            le nouveau seuil
	 */
	public abstract void setSeuil(double unSeuil);

}