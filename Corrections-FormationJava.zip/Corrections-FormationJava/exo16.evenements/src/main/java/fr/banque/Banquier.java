package fr.banque;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.Serializable;

/**
 * Ceci est la classe banquier. <br/>
 *
 * Il est interesse quand un objet de type compte change d'etat. <br/>
 */
public class Banquier implements PropertyChangeListener, Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur.
	 */
	public Banquier() {
		super();
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		// On regarde l'objet qui a emit l'evenement
		if (evt.getSource() instanceof Compte) {
			Compte cpt = (Compte) evt.getSource();
			System.out.println("Changement du compte Id" + cpt.getNumero());
			System.out.println(
					"\t" + evt.getPropertyName() + " est passe de " + evt.getOldValue() + " a " + evt.getNewValue());
		}
	}

}
