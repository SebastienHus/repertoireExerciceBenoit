/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package fr.banque;

import org.junit.Assert;
import org.junit.Test;

import fr.banque.Client;
import fr.banque.Compte;

/**
 * Test sur la classe fr.banque.Client.
 */
public class TestClient {

	/**
	 * Test sur la methode ajouterCompte de la classe Client.
	 */
	@Test
	public void testAjouterCompte() {
		Client unClient = new Client();
		Compte unCompte = new Compte(Integer.valueOf(1), Double.valueOf(5000));
		unClient.ajouterCompte(unCompte);
		Assert.assertTrue("Le client doit avoir un seul compte", unClient.getComptes().length == 1);
	}
}
