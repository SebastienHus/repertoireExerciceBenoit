package fr;

import fr.banque.Client;
import fr.banque.Compte;

/**
 * La classe de lancement. <br/>
 */
public class Run {

	/**
	 * Lancement des tests. <br>
	 *
	 * @param args
	 *            les arguments de lancement
	 */
	public static void main(String[] args) {
		// Creation du client principale Mr Dupont
		Client client = new Client(1, "Dupont", "Henry", 28);
		// Creation des comptes
		Compte c0 = new Compte(0, 200);
		Compte c1 = new Compte(1, 1000);
		Compte c2 = new Compte(2, 400);
		// Lien entre le client est ses comptes
		client.ajouterCompte(c0);
		client.ajouterCompte(c1);
		client.ajouterCompte(c2);
		// Affichage d'un client
		System.out.println(client);
		// Ajoutons 50 au compte n°1
		client.getCompte(1).ajouter(50);
		// Affichage du compte
		System.out.println(client.getCompte(1));
	}
}