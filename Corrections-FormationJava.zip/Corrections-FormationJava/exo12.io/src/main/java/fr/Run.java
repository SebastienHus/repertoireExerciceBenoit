package fr;

import java.io.IOException;
import java.util.List;

import fr.io.NomPrenomReaderIO;
import fr.io.UtilisateurWriter;

/**
 * Classe qui charge les noms et les prenoms et fabrique une liste de personnes.
 * <br/>
 */
public class Run {

	/**
	 * Methode de lancement.
	 *
	 * @param args
	 *            ne sert pas ici
	 */
	public static void main(String[] args) {
		System.out.println("-- Debut --");
		// Potentiellement changer ce chemin sur votre ordinateur
		final String root = "T:/Workspace/Exo12-IO/src/main/resources/";
		final String resultat = "resultat.csv";
		NomPrenomReaderIO.setROOT(root);
		UtilisateurWriter.setRoot(root);
		try {
			List<String> noms = NomPrenomReaderIO.readNom();
			List<String> prenoms = NomPrenomReaderIO.readPrenom();
			UtilisateurWriter.writerUtilisateur(resultat, noms, prenoms, 50);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("-- Fin --");
	}

}
