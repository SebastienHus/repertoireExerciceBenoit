package fr.io;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Classe qui ecrit un fichier CSV avec comme formalisme
 * numero;genre;nom;prenom. <br/>
 */
public class UtilisateurWriter {
	/** Repertoire racine du fichier resultat. */
	private static String root;
	/** Separateur pour le fichier CSV. */
	public static final String SEPRATEUR = ";";

	/**
	 * Indique le chemin racine.
	 *
	 * @param aRoot
	 *            le chemin racine.
	 */
	public static void setRoot(String aRoot) {
		UtilisateurWriter.root = aRoot;
	}

	/**
	 * Lit le fichier des noms et retourne une liste de String qui le
	 * represente.
	 *
	 * @param unNomDeFichier
	 *            le nom du fichier de destination
	 * @param desNoms
	 *            la liste des noms
	 * @param desPrenoms
	 *            la liste des prenoms
	 * @param combien
	 *            combien l'on veut de ligne
	 * @throws IOException
	 *             si un probleme survient
	 */
	public static void writerUtilisateur(String unNomDeFichier, List<String> desNoms, List<String> desPrenoms,
			int combien) throws IOException {
		File fichierOut = new File(UtilisateurWriter.root, unNomDeFichier);
		fichierOut.createNewFile();
		if (!fichierOut.exists() || !fichierOut.canWrite()) {
			throw new IOException("Probleme d'acces au fichier " + fichierOut);
		}
		// On melange les deux liste
		Collections.shuffle(desNoms);
		Collections.shuffle(desPrenoms);
		// On utilise trois generateurs
		Random randomNom = new Random();
		Random randomPrenom = new Random();
		Random randomGenre = new Random();
		BufferedWriter buffered = null;
		FileOutputStream fos = null;
		OutputStreamWriter osw = null;
		try {
			// Afin de rester en UTF-8
			fos = new FileOutputStream(fichierOut);
			osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
			buffered = new BufferedWriter(osw);
			// On recupere le separateur de ligne
			// On peut aussi choisir \n
			final String nl = System.getProperty("line.separator");
			for (int i = 0; i < combien; i++) {
				String nom = desNoms.get(randomNom.nextInt(desNoms.size()));
				String prenom = desPrenoms.get(randomPrenom.nextInt(desPrenoms.size()));
				String genre = randomGenre.nextBoolean() ? "Mr" : "Mm";
				StringBuilder ligne = new StringBuilder();
				ligne.append(i).append(UtilisateurWriter.SEPRATEUR);
				ligne.append(genre).append(UtilisateurWriter.SEPRATEUR);
				ligne.append(nom).append(UtilisateurWriter.SEPRATEUR);
				ligne.append(prenom).append(nl);
				buffered.write(ligne.toString());
			}
			buffered.flush();
		} catch (Exception e) {
			// On relance l'exception
			throw new IOException("Erreur lors de l'ecriture du fichier " + fichierOut, e);
		} finally {
			// On ferme les flux dans le finally
			if (buffered != null) {
				buffered.close();
			}
			if (osw != null) {
				osw.close();
			}
			if (fos != null) {
				fos.close();
			}
		}
	}
}
