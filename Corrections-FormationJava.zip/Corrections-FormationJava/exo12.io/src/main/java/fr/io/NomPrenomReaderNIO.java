package fr.io;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * Classe qui charge les noms et les prenoms en utilisant l'api NIO. <br/>
 *
 * @since 1.7
 */
public class NomPrenomReaderNIO {
	/** Repertoire racine des deux autres fichiers. */
	private static String ROOT;
	/** Nom du fichier qui contient les noms. */
	private static final String FICHIER_NOM = "nom.txt";
	/** Nom du fichier qui contient les prenoms. */
	private static final String FICHIER_PRENOM = "prenom.txt";

	/**
	 * Indique le chemin racine.
	 *
	 * @param aRoot
	 *            le chemin racine.
	 */
	public static void setROOT(String aRoot) {
		NomPrenomReaderNIO.ROOT = aRoot;
	}

	/**
	 * Lit le fichier et retourne une liste de String qui le represente.
	 *
	 * @return la liste representant chaque ligne du fichier
	 * @throws IOException
	 *             si un probleme survient
	 * @since 1.7
	 */
	private static List<String> readFichier(String unNomDeFichier) throws IOException {
		Path fichierNom = Paths.get(NomPrenomReaderNIO.ROOT, unNomDeFichier);
		if (!Files.exists(fichierNom) || !Files.isReadable(fichierNom)) {
			throw new IOException("Probleme d'acces au fichier " + fichierNom);
		}
		// C'est plus court en NIO qu'en IO
		return Files.readAllLines(fichierNom, StandardCharsets.UTF_8);
	}

	/**
	 * Lit le fichier des noms et retourne une liste de String qui le
	 * represente.
	 *
	 * @return la liste des noms
	 * @throws IOException
	 *             si un probleme survient
	 *
	 * @since 1.7
	 */
	public static List<String> readNom() throws IOException {
		return NomPrenomReaderNIO.readFichier(NomPrenomReaderNIO.FICHIER_NOM);
	}

	/**
	 * Lit le fichier des prenoms et retourne une liste de String qui le
	 * represente.
	 *
	 * @return la liste des prenoms
	 * @throws IOException
	 *             si un probleme survient
	 * @since 1.7
	 */
	public static List<String> readPrenom() throws IOException {
		return NomPrenomReaderNIO.readFichier(NomPrenomReaderNIO.FICHIER_PRENOM);
	}
}
