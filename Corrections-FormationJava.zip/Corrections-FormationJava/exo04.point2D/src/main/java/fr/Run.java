package fr;

import fr.dessin.Point2D;

/**
 * La classe de lancement. <br/>
 */
public class Run {

	/**
	 * Pour tester. <br/>
	 *
	 * @param args
	 *            les arguments
	 */
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Point2D p1 = new Point2D();
		Point2D p2 = new Point2D();
		Point2D p3 = new Point2D(5, 5);
		// Lors de l'appel a une methode static il faut prefixer par le nom de
		// la classe
		System.out.println("Nb Point2D :" + Point2D.getCompteur());
	}

}
