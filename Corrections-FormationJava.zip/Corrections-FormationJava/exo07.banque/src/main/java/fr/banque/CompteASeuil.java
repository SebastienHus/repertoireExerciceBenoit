package fr.banque;

/**
 * Ceci est la classe Compte a seuil. <br/>
 * Il n'est pas possible de descendre en dessous du seuil.
 */
public class CompteASeuil extends Compte {
	private double seuil;

	/**
	 * Constructeur. <br/>
	 * Le seuil par defaut est de 0
	 */
	public CompteASeuil() {
		this(-1, 0, 0);
	}

	/**
	 * Constructeur de l'objet. <br>
	 *
	 * @param unNumero
	 *            le numero du compte
	 * @param unSoldeInitial
	 *            le solde initial du compte
	 * @param unSeuil
	 *            un seuil
	 */
	public CompteASeuil(int unNumero, double unSoldeInitial, double unSeuil) {
		super(unNumero, unSoldeInitial);
		this.setSeuil(unSeuil);
	}

	/**
	 * Recupere le seuil.
	 *
	 * @return le seuil
	 */
	public double getSeuil() {
		return this.seuil;
	}

	/**
	 * Modifie la valeur du seuil.
	 *
	 * @param unSeuil
	 *            le nouveau seuil
	 */
	public void setSeuil(double unSeuil) {
		this.seuil = unSeuil;
	}

	@Override
	public String toString() {
		return String.format("%s Seuil=%f", super.toString(), this.getSeuil());
	}

	@Override
	public void retirer(double unMontant) {
		double simu = this.getSolde() - unMontant;
		if (simu <= this.getSeuil()) {
			// Pas bon, on ne fait rien, pour l'instant
		} else {
			super.retirer(unMontant);
		}
	}
}
