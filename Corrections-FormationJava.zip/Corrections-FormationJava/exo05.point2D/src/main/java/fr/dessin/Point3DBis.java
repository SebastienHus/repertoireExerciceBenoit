package fr.dessin;

/**
 * Ici, on fait usage de la composition. <br/>
 *
 * On ne veut pas que le Point3D herite du Point2D, on peut donc fair en sorte
 * que le Point3D est compose d'un Point2D. <br/>
 *
 * Les methodes getX/getY/translater deleguent a l'attribut de type Point2D de
 * notre Point3D.
 */
public class Point3DBis {
	// Notre Point3DBis aura un attribut de type Point2D
	private Point2D p;

	private int z;

	/**
	 * Constructeur.
	 */
	public Point3DBis() {
		this(0, 0, 0);
		// Chainage de constructeur
		// On commence par ecrire le plus complique
		// Puis les autres y font appel
	}

	/**
	 * Constructeur.
	 *
	 * @param vX
	 *            valeur pour X
	 * @param vY
	 *            valeur pour Y
	 * @param vZ
	 *            valeur pour Z
	 */
	public Point3DBis(int vX, int vY, int vZ) {
		super();
		// Nous somme en composition, Point3D est responsable de la fabrication
		// de son Point2D
		this.p = new Point2D(vX, vY);
		this.setZ(vZ);
	}

	/**
	 * Recupere la valeur de x.
	 *
	 * @return la valeur de x.
	 */
	public int getX() {
		return this.p.getX();
	}

	/**
	 * Recupere la valeur de y.
	 *
	 * @return la valeur de y.
	 */
	public int getY() {
		return this.p.getY();
	}

	/**
	 * Modifie la valeur de x. <br/>
	 *
	 * @param valX
	 *            la nouvelle valeur de x
	 */
	public void setX(int valX) {
		this.p.setX(valX);
	}

	/**
	 * Modifie la valeur de y. <br/>
	 *
	 * @param valY
	 *            la nouvelle valeur de y
	 */
	public void setY(int valY) {
		this.p.setY(valY);
	}

	/**
	 * Recupere la valeur de Z
	 *
	 * @return la valeur de Z
	 */
	public int getZ() {
		return this.z;
	}

	/**
	 * Modifie la valeur de Z
	 *
	 * @param dZ
	 *            la nouvelle valeur de z
	 */
	public void setZ(int dZ) {
		this.z = dZ;
	}

	/**
	 * Translate le point sur 3 axes.
	 *
	 * @param dX
	 *            valeur de translation en x
	 * @param dY
	 *            valeur de translation en y
	 * @param dZ
	 *            valeur de translation en z
	 */
	public void translater(int dX, int dY, int dZ) {
		this.p.translater(dX, dY);
		this.setZ(this.getZ() + dZ);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getClass().getName());
		builder.append(" [x=").append(this.getX());
		builder.append(", y=").append(this.getY());
		builder.append(", z=").append(this.getZ()).append(']');
		return builder.toString();
	}

	@Override
	public int hashCode() {
		return (this.getClass() + "_" + this.getX() + "_" + this.getY() + "_" + this.getZ()).hashCode();

	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (obj instanceof Point3DBis) {
			Point3DBis other = (Point3DBis) obj;
			return this.getX() == other.getX() && this.getY() == other.getY() && this.getZ() == other.getZ();
		}
		return false;
	}

}
