package com.travel.dao;

import javax.persistence.EntityManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.travel.entities.Client;
import com.travel.exception.ResourceNotFoundException;
import com.travel.listeners.ApplicationListener;

public class ClientDao {

	private static final Logger LOG = LogManager.getLogger(ClientDao.class);

	public ClientDao() {}

	public void addClient(Client client) {
		EntityManager em = ApplicationListener.getEmf().createEntityManager();
		em.getTransaction().begin();
		try {
			em.persist(client);
			//Valide les traitements
			em.getTransaction().commit();
		} catch (Exception e) {
			LOG.error(e.getMessage());
			// Annule les traitements
			em.getTransaction().rollback();
		}finally {
			em.close();
		}
	}

	public Client getClientById(long id) {
		EntityManager em = ApplicationListener.getEmf().createEntityManager();
		Client client =  em.find(Client.class, id);
		if (client != null) {
			em.close();
			return client;
		} else {
			em.close();
			throw new ResourceNotFoundException("Client", "id", id);
		}
	}

	public void updateClient(long id, Client updateClient) {
		EntityManager em = ApplicationListener.getEmf().createEntityManager();
		try {
			Client client = em.find(Client.class, id);
			System.out.println(client);
			if (client != null ) {
				em.getTransaction().begin();
				client.setFirstname(updateClient.getFirstname());
				client.setLastname(updateClient.getLastname());
				client.setEmail(updateClient.getEmail());
				client.setPassword(updateClient.getPassword());
				client.setAdresse(updateClient.getAdresse());
				em.getTransaction().commit();
			}
		} catch (Exception e) {
			em.getTransaction().rollback();
			LOG.error(e.getMessage());
		}finally {
			em.close();
		}


	}
}
