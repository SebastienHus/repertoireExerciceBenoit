package com.travel.dao;

import javax.persistence.EntityManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.travel.entities.Travel;
import com.travel.exception.ResourceNotFoundException;
import com.travel.listeners.ApplicationListener;

public class TravelDao {

	private static final Logger LOG = LogManager.getLogger(TravelDao.class);

	public TravelDao() {
	}

	public void addTravel(Travel travel) {
		EntityManager em = ApplicationListener.getEmf().createEntityManager();
		em.getTransaction().begin();
		try {
			em.persist(travel);
			em.getTransaction().commit();
			LOG.debug("Travel saved");
		} catch(Exception e) {
			LOG.error(e.getMessage());
			em.getTransaction().rollback();

		} finally {
			em.close();
		}
	}

	public Travel getTravelById(long id) {
		EntityManager em = ApplicationListener.getEmf().createEntityManager();
		Travel travel = em.find(Travel.class, id);
		if( travel != null) {
			em.close();
			return travel;
		} else {
			em.close();
			throw new ResourceNotFoundException("travel", "id", id);
		}
	}

}
