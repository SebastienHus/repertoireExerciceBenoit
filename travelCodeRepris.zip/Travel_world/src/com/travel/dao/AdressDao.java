package com.travel.dao;

import javax.persistence.EntityManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.travel.entities.Adress;
import com.travel.exception.ResourceNotFoundException;
import com.travel.listeners.ApplicationListener;

public class AdressDao {
	public static final Logger LOG = LogManager.getLogger(AdressDao.class);

	public AdressDao() {
	}

	public void addAdress(Adress adress) {
		EntityManager em = ApplicationListener.getEmf().createEntityManager();
		em.getTransaction().begin();
		try {
			em.persist(adress);
			em.getTransaction().commit();
		} catch (Exception e) {
			LOG.error(e.getMessage());
			// Annule les traitements
			em.getTransaction().rollback();
		}finally {
			em.close();
		}

	}

	public Adress getAdressById(long id) {
		EntityManager em = ApplicationListener.getEmf().createEntityManager();
		Adress adress =  em.find(Adress.class, id);
		if (adress != null) {
			em.close();
			return adress;
		} else {
			em.close();
			throw new ResourceNotFoundException("Adresse", "id", id);
		}
	}
}
