package com.travel.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="adresses")
public class Adress {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	private int cp;
	private String street;
	private String town;

	@OneToOne(mappedBy = "adresse")
	private Client client;

	public Client getClient() {
		return this.client;
	}



	public void setClient(Client client) {
		this.client = client;
	}



	public Adress() {
	}



	public Adress(int cp, String street, String town) {
		super();
		this.cp = cp;
		this.street = street;
		this.town = town;
	}



	public int getCp() {
		return this.cp;
	}

	public void setCp(int cp) {
		this.cp = cp;
	}

	public String getStreet() {
		return this.street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getTown() {
		return this.town;
	}

	public void setTown(String town) {
		this.town = town;
	}



	public long getId() {
		return this.id;
	}



	public void setId(long id) {
		this.id = id;
	}



	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Adress [id=");
		builder.append(this.id);
		builder.append(", cp=");
		builder.append(this.cp);
		builder.append(", street=");
		builder.append(this.street);
		builder.append(", town=");
		builder.append(this.town);
		builder.append("]");
		return builder.toString();
	}

}
