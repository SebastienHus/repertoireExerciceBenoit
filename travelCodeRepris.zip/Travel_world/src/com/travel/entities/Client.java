package com.travel.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="clients")
public class Client implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(length=50, nullable=false)
	private String firstname;

	@Column(length=50, nullable=false)
	private String lastname;

	@Column(length=100, nullable=false)
	private String email;
	@Column(length=100, nullable=false)
	private String password;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "fk_adresse_id")
	private Adress adresse;

	@ManyToMany(cascade = { CascadeType.ALL })
	@JoinTable(
			name = "Client_Travel",
			joinColumns = { @JoinColumn(name = "client_id") },
			inverseJoinColumns = { @JoinColumn(name = "travel_id") }
			)
	List<Travel> travels = new ArrayList<>();

	public Client() {}

	public Client(String firstname, String lastname, String email, String password, Adress adress) {
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.password = password;
		this.adresse = adress;
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return this.lastname;
	}

	public Adress getAdresse() {
		return this.adresse;
	}

	public void setAdresse(Adress adresse) {
		this.adresse = adresse;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Travel> getTravels() {
		return this.travels;
	}

	public void setTravels(List<Travel> travels) {
		this.travels = travels;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Client [id=");
		builder.append(this.id);
		builder.append(", firstname=");
		builder.append(this.firstname);
		builder.append(", lastname=");
		builder.append(this.lastname);
		builder.append(", email=");
		builder.append(this.email);
		builder.append(", password=");
		builder.append(this.password);
		builder.append(", adresse=");
		builder.append(this.adresse);
		builder.append("]");
		return builder.toString();
	}

}
