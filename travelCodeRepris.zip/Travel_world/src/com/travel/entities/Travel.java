package com.travel.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="travels")
public class Travel implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(length=100, nullable=false)
	private String destination;

	@Column(nullable=false)
	private String description;

	@Column(nullable=false)
	private int price;

	@ManyToMany(mappedBy = "travels")
	private List<Client> clients = new ArrayList<>();


	public Travel() {
	}

	public Travel( String destination, String description, int price) {
		this.destination = destination;
		this.description = description;
		this.price = price;
	}

	public String getDestination() {
		return this.destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrice() {
		return this.price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public List<Client> getClients() {
		return this.clients;
	}

	public void setClients(List<Client> clients) {
		this.clients = clients;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Travel [destination=");
		builder.append(this.destination);
		builder.append(", description=");
		builder.append(this.description);
		builder.append(", price=");
		builder.append(this.price);
		builder.append("]");
		return builder.toString();
	}



}
