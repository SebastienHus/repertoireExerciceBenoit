package com.travel.servlets;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.travel.entities.Adress;
import com.travel.entities.Client;
import com.travel.entities.Travel;
import com.travel.listeners.ApplicationListener;


@WebServlet(urlPatterns = {"","/Home"})
public class Home extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LogManager.getLogger(Home.class);


	public Home() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("Test insertion client en BDD");
		Client client = new Client("Tom", "a","toma@mail.com", "pwd",new Adress(5900, "avenue de bretagne", "Lille"));
		client.getTravels().add(new Travel("Italie", "Description", 400));
		EntityManager em = ApplicationListener.getEmf().createEntityManager();
		em.getTransaction().begin();
		try {
			em.persist(client);
			em.getTransaction().commit();
		} catch(Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}


		this.getServletContext().getRequestDispatcher("/WEB-INF/home.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}

}
