package com.travel.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.travel.dao.TravelDao;
import com.travel.entities.Travel;

/**
 * Servlet implementation class Travel
 */
@WebServlet("/travel")
public class CreateTravel extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LogManager.getLogger(CreateTravel.class);
	private static TravelDao travelDao = new TravelDao();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CreateTravel() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Travel travel  = new Travel("Islande", "Description", 5000);
		Travel travelBdd = travelDao.getTravelById(2);
		System.out.println(travelBdd);
		this.getServletContext().getRequestDispatcher("/WEB-INF/travelForm.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Travel formTravel = new Travel(
				request.getParameter("destination"),
				request.getParameter("description"),
				Integer.parseInt(request.getParameter("price")));
		travelDao.addTravel(formTravel);
		this.getServletContext().getRequestDispatcher("/WEB-INF/travelForm.jsp").forward(request, response);
	}

}
